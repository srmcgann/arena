#!/bin/bash
./setDomainBatch.sh fishable-searches.000webhostapp.com id21284549_user id21284549_videodemos2
mv *.zip ..
./setDomainBatch.sh orbs2.000webhostapp.com id21552617_user id21552617_orbs2
mv *.zip ..
./setDomainBatch.sh orbs3.000webhostapp.com id21553412_user id21553412_orbs3
mv *.zip ..
./setDomainBatch.sh orbs4.000webhostapp.com id21583283_user id21583283_orbs4
mv *.zip ..
./setDomainBatch.sh efx2.000webhostapp.com id21601194_user id21601194_efx2
mv *.zip ..
./setDomainBatch.sh efx3.000webhostapp.com id21601862_user id21601862_efx3
mv *.zip ..
./setDomainBatch.sh warpspeed.000webhostapp.com id21607252_user id21607252_warpspeed
mv *.zip ..
./setDomainBatch.sh orbstools.000webhostapp.com id21594651_user id21594651_orbstools
mv *.zip ..
#./setDomainBatch efx3.000webhostapp.com id21601862_user id21601862_efx3
#mv *.zip ..
